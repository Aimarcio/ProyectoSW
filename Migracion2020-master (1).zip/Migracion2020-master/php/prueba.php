<?php phpinfo(); ?>
