<?php
    $local=1; //0 para la nube
    if ($local==1) {
        $server="localhost";
        $user="root";
        $pass="";
        $basededatos="quiz";
    }
    else {
        $server="localhost";
        $user="id15117638_admin";
        $pass="***hidden***";
        $basededatos="id15117638_quiz";
    }
?>
