<?php
    $local=0; //0 para la nube
    if ($local==1) {
        $server="localhost";
        $user="root";
        $pass="";
        $basededatos="quiz";
    }
    else {
        $server="localhost";
        $user="id14879003_aimarcio";
        $pass="oqxhlS43$[lurwJc";
        $basededatos="id14879003_quiz";
    }
?>
